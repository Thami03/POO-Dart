Atividade para a disciplina de Programação orientada a Objetos. 
link:https://zapp.run/edit/receita1-zz3206imz330?entry=lib%2Fmain.dart